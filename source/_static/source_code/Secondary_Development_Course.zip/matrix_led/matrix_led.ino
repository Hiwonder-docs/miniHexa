#include "hiwonder_robot.h"
#include "hiwonder_sensor.h"
#include "WMMatrixLED.h"

//Create miniHexa object (创建miniHexa对象)
Robot minihexa;
//Initialize matrix module pins (初始化点阵模块引脚)
WMMatrixLed matrix(14, 32);  //  SCK / DIN pin numbers (SCK / DIN 引脚编号)

void setup() {
  Serial.begin(115200);
  minihexa.begin();
  matrix.setBrightness(5);//Set brightness (设置亮度)
  matrix.clearScreen();//Clear screen (清屏幕)
}
int x;
void loop() {
  const char* text = "Hiwonder";
  int textWidth = 6 * strlen(text); // Each character ~6 pixels (每个字符约6像素)
  for (int x = 16; x > -textWidth; x--) {
    matrix.drawStr(x, 8, text);       //Start displaying (开始显示)
    delay(100);
  }
}
