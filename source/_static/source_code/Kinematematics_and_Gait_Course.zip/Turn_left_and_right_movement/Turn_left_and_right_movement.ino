#include "hiwonder_robot.h"

//Initialize miniHexa object (初始化miniHexa对象)
Robot minihexa;

//Initialize motion state (初始化运动状态)
Velocity_t vel = {0.0f,0.0f,0.0f};
Vector_t pos = {0.0f,0.0f,0.0f};
Euler_t att = {0.0f,0.0f,0.0f};

void setup() {
  Serial.begin(115200);
  minihexa.begin();
}

void loop() {
    vel = {0.0f, 5.0f, 0.2f};// Arc-shaped forward left (弧形左前进)
    minihexa.move(&vel, &pos, &att);//Execute movement (执行移动)
    delay(5000);

    vel = {0.0f, 5.0f, -0.2f};//Arc-shaped forward right (弧形右前进)
    minihexa.move(&vel, &pos, &att);//Execute movement (执行移动)
    delay(5000);
}

